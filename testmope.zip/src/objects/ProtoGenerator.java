package objects;

public class ProtoGenerator extends GameObject {
	
	public int amount = 0;

	public ProtoGenerator(int id, int x, int y, int radius, int type) {
		super(id, x, y, radius, type);
	}

}
